"""Structured console and file logging with Rich."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from rich.console import Console
from rich.logging import RichHandler
from rich.traceback import install as rich_install


def setup_logging(
    log_level: str,
    logs_dir: Path,
    app_name: str = "gemini_srt",
) -> logging.Logger:
    """
    Configure root logging with Rich console output and rotating file logs.

    Returns the application logger.
    """
    rich_install(show_locals=False)

    logs_dir.mkdir(parents=True, exist_ok=True)
    log_file = logs_dir / f"{app_name}.log"
    error_file = logs_dir / f"{app_name}_errors.log"

    level = getattr(logging, log_level.upper(), logging.INFO)

    console = Console(stderr=True)
    rich_handler = RichHandler(
        console=console,
        rich_tracebacks=True,
        tracebacks_show_locals=False,
        markup=True,
        show_time=True,
        show_path=False,
    )
    rich_handler.setLevel(level)

    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=20 * 1024 * 1024,
        backupCount=10,
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    error_handler = RotatingFileHandler(
        error_file,
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)
    root.addHandler(rich_handler)
    root.addHandler(file_handler)
    root.addHandler(error_handler)

    logging.captureWarnings(True)

    logger = logging.getLogger(app_name)
    logger.debug("Logging initialized at level %s", log_level)
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a module-level logger under the application namespace."""
    return logging.getLogger(name or "gemini_srt")
