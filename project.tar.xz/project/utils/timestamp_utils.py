"""Timestamp conversion utilities for SRT (HH:MM:SS,mmm)."""

from __future__ import annotations


def seconds_to_srt_timestamp(seconds: float) -> str:
    """
    Convert floating-point seconds to SRT timestamp format.

    Negative values are clamped to zero.
    """
    if seconds < 0:
        seconds = 0.0
    ms_total = int(round(seconds * 1000.0))
    ms = ms_total % 1000
    s_total = ms_total // 1000
    s = s_total % 60
    m_total = s_total // 60
    m = m_total % 60
    h = m_total // 60
    if h > 99:
        h = 99
        m = 59
        s = 59
        ms = 999
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def normalize_overlap_segments(
    segments: list[tuple[float, float, str]],
) -> list[tuple[float, float, str]]:
    """
    Sort by start time and fix minor overlaps by nudging end times.

    Expects tuples of (start_sec, end_sec, text).
    """
    if not segments:
        return []
    ordered = sorted(segments, key=lambda item: (item[0], item[1]))
    fixed: list[tuple[float, float, str]] = []
    eps = 1e-3
    prev_end = 0.0
    for start, end, text in ordered:
        start = max(start, 0.0)
        if start < prev_end:
            start = prev_end
        if end <= start:
            end = start + eps
        fixed.append((start, end, text.strip()))
        prev_end = max(prev_end, end)
    return fixed
