"""Async-friendly filesystem helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import aiofiles


async def write_text_async(path: Path, content: str, encoding: str = "utf-8") -> None:
    """Write UTF-8 text asynchronously, creating parent directories."""
    path.parent.mkdir(parents=True, exist_ok=True)
    async with aiofiles.open(path, "w", encoding=encoding, newline="\n") as handle:
        await handle.write(content)


async def write_json_async(path: Path, payload: Any) -> None:
    """Serialize JSON asynchronously with stable formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2, ensure_ascii=False)
    async with aiofiles.open(path, "w", encoding="utf-8") as handle:
        await handle.write(text)


def write_json_sync(path: Path, payload: Any) -> None:
    """Serialize JSON synchronously (for shutdown hooks)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


async def read_json_async(path: Path) -> Any:
    """Load JSON asynchronously."""
    async with aiofiles.open(path, "r", encoding="utf-8") as handle:
        raw = await handle.read()
    return json.loads(raw)
