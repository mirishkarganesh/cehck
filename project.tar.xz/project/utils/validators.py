"""Audio validation helpers using ffprobe."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from models.schemas import FailureReason


class AudioProbeError(Exception):
    """Raised when ffprobe cannot parse audio metadata."""

    def __init__(self, message: str, reason: FailureReason) -> None:
        super().__init__(message)
        self.reason = reason


def probe_wav_duration_seconds(path: Path, ffprobe_bin: str = "ffprobe") -> float:
    """
    Return audio duration in seconds using ffprobe JSON output.

    Raises AudioProbeError on failure or unsupported content.
    """
    cmd = [
        ffprobe_bin,
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired as exc:
        raise AudioProbeError(
            f"ffprobe timed out for {path}",
            FailureReason.INVALID_AUDIO,
        ) from exc
    except FileNotFoundError as exc:
        raise AudioProbeError(
            "ffprobe executable not found; install FFmpeg.",
            FailureReason.FFMPEG_ERROR,
        ) from exc

    if proc.returncode != 0:
        raise AudioProbeError(
            proc.stderr.strip() or "ffprobe failed",
            FailureReason.INVALID_AUDIO,
        )

    try:
        payload = json.loads(proc.stdout or "{}")
        duration_raw = payload.get("format", {}).get("duration")
        if duration_raw is None:
            raise AudioProbeError(
                "Missing duration in ffprobe output",
                FailureReason.UNSUPPORTED_FORMAT,
            )
        duration = float(duration_raw)
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        raise AudioProbeError(
            f"Cannot parse ffprobe JSON for {path}",
            FailureReason.INVALID_AUDIO,
        ) from exc

    if duration <= 0:
        raise AudioProbeError(
            "Audio duration is zero or negative",
            FailureReason.EMPTY_AUDIO,
        )

    return duration


def validate_wav_suffix(path: Path) -> None:
    """Ensure filename extension indicates WAV."""
    if path.suffix.lower() != ".wav":
        raise AudioProbeError(
            f"Expected .wav extension, got {path.suffix!r}",
            FailureReason.UNSUPPORTED_FORMAT,
        )
