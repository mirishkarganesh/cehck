"""Domain schemas for transcription, chunking, and batch reporting."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any
from pydantic import BaseModel, Field, field_validator, model_validator


class FailureReason(str, Enum):
    """Standardized failure categories for observability."""

    INVALID_AUDIO = "invalid_audio"
    UNSUPPORTED_FORMAT = "unsupported_format"
    EMPTY_AUDIO = "empty_audio"
    API_ERROR = "api_error"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    FFMPEG_ERROR = "ffmpeg_error"
    PARSE_ERROR = "parse_error"
    UNKNOWN = "unknown"


class TranscriptionSegment(BaseModel):
    """A single timed subtitle segment relative to its source clip."""

    start_seconds: float = Field(..., ge=0.0)
    end_seconds: float = Field(..., ge=0.0)
    text: str = Field(..., min_length=1)

    @field_validator("text")
    @classmethod
    def strip_text(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Segment text cannot be empty")
        return cleaned

    @model_validator(mode="after")
    def validate_order(self) -> TranscriptionSegment:
        if self.end_seconds < self.start_seconds:
            raise ValueError("end_seconds must be >= start_seconds")
        return self


class AudioChunkPlan(BaseModel):
    """Describes one temporal slice of a larger WAV file."""

    index: int = Field(..., ge=0)
    start_seconds: float = Field(..., ge=0.0)
    duration_seconds: float = Field(..., gt=0.0)


class FileProcessingResult(BaseModel):
    """Outcome for a single input WAV."""

    input_path: Path
    output_path: Path | None = None
    success: bool
    duration_seconds: float | None = None
    chunks_processed: int = 0
    elapsed_seconds: float = 0.0
    failure_reason: FailureReason | None = None
    detail: str | None = None


class BatchProcessingReport(BaseModel):
    """Aggregate statistics for a batch run."""

    started_at: datetime
    finished_at: datetime | None = None
    total_files: int = 0
    succeeded: int = 0
    skipped: int = 0
    failed: int = 0
    total_wall_seconds: float = 0.0
    results: list[FileProcessingResult] = Field(default_factory=list)

    def to_summary_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable summary."""
        return {
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "total_files": self.total_files,
            "succeeded": self.succeeded,
            "skipped": self.skipped,
            "failed": self.failed,
            "total_wall_seconds": self.total_wall_seconds,
            "success_rate": (
                self.succeeded / self.total_files if self.total_files else 0.0
            ),
        }


class PipelineStateFile(BaseModel):
    """Persisted resume/skip state across runs."""

    version: int = 1
    completed_paths: dict[str, str] = Field(default_factory=dict)
    """Maps normalized input path string -> output SRT path string."""
