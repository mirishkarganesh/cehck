"""CLI entrypoint orchestrating batch Gemini transcription into SRT subtitles."""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from dotenv import load_dotenv
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import Settings, get_settings  # noqa: E402
from models.schemas import (  # noqa: E402
    BatchProcessingReport,
    FileProcessingResult,
    PipelineStateFile,
)
from services.audio_processor import extract_wav_segment  # noqa: E402
from services.chunking import plan_audio_chunks  # noqa: E402
from services.gemini_transcriber import (  # noqa: E402
    GeminiTranscriber,
    classify_gemini_failure,
    merge_adjacent_chunks,
    normalize_segment_timeline,
    shift_segments,
)
from services.srt_generator import build_srt_document  # noqa: E402
from utils.file_utils import read_json_async, write_json_async, write_json_sync, write_text_async  # noqa: E402
from utils.logger import setup_logging  # noqa: E402
from utils.validators import AudioProbeError, probe_wav_duration_seconds, validate_wav_suffix  # noqa: E402

STATE_FILENAME = ".gemini_srt_state.json"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Construct the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Generate SRT subtitles from WAV audio via Gemini multimodal transcription.",
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        help="Directory containing source WAV files (defaults to INPUT_DIR).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="Directory where SRT files are written (defaults to OUTPUT_DIR).",
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Discover WAV files recursively.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        help="Concurrent files being processed (defaults to MAX_WORKERS).",
    )
    parser.add_argument(
        "--chunk-duration",
        type=float,
        help="Seconds per Gemini chunk for long audio (defaults to CHUNK_DURATION_SEC).",
    )
    parser.add_argument(
        "--model",
        type=str,
        help="Override Gemini model id (defaults to MODEL_NAME).",
    )
    parser.add_argument(
        "--prompt-file",
        type=Path,
        help="Optional UTF-8 text file overriding the transcription prompt.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Regenerate subtitles even when outputs already exist.",
    )
    parser.add_argument(
        "--no-state",
        action="store_true",
        help="Disable persistent resume state tracking.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List discovered files without contacting Gemini.",
    )
    return parser.parse_args(argv)


def apply_cli_overrides(args: argparse.Namespace) -> None:
    """Apply CLI arguments via environment variables consumed by Settings."""
    if args.workers is not None:
        os.environ["MAX_WORKERS"] = str(args.workers)
    if args.chunk_duration is not None:
        os.environ["CHUNK_DURATION_SEC"] = str(args.chunk_duration)
    if args.model:
        os.environ["MODEL_NAME"] = args.model
    if args.input_dir:
        os.environ["INPUT_DIR"] = str(args.input_dir.expanduser())
    if args.output_dir:
        os.environ["OUTPUT_DIR"] = str(args.output_dir.expanduser())


def discover_wav_files(root: Path, *, recursive: bool) -> list[Path]:
    """Return sorted WAV paths under ``root``."""
    pattern = "*.wav"
    iterator: Iterable[Path]
    if recursive:
        iterator = root.rglob(pattern)
    else:
        iterator = root.glob(pattern)
    discovered = [path for path in iterator if path.suffix.lower() == ".wav"]
    return sorted({path.resolve() for path in discovered})


def resolve_output_path(input_root: Path, output_root: Path, wav_path: Path) -> Path:
    """Mirror relative paths while swapping extensions to ``.srt``."""
    input_root = input_root.resolve()
    wav_path = wav_path.resolve()
    relative = wav_path.relative_to(input_root)
    return (output_root / relative).with_suffix(".srt")


def load_prompt(args: argparse.Namespace) -> str | None:
    """Load optional custom prompt text."""
    if not args.prompt_file:
        return None
    path = args.prompt_file.expanduser().resolve()
    return path.read_text(encoding="utf-8")


async def load_pipeline_state(path: Path) -> PipelineStateFile:
    """Load JSON state or return empty model."""
    if not path.exists():
        return PipelineStateFile()
    try:
        raw = await read_json_async(path)
        return PipelineStateFile.model_validate(raw)
    except Exception:
        return PipelineStateFile()


def transcribe_wav_sync(
    wav_path: Path,
    *,
    settings: Settings,
    transcriber: GeminiTranscriber,
):
    """Synchronously transcribe a WAV file (supports chunking)."""
    from models.schemas import TranscriptionSegment  # noqa: PLC0415

    validate_wav_suffix(wav_path)
    duration = probe_wav_duration_seconds(wav_path)
    chunks = plan_audio_chunks(duration, settings.chunk_duration_sec)

    if len(chunks) == 1:
        segments = transcriber.transcribe_path_auto(wav_path)
        return normalize_segment_timeline(segments)

    collected: list[TranscriptionSegment] = []
    with tempfile.TemporaryDirectory(prefix="gemini_srt_chunk_") as tmpdir:
        tmp_root = Path(tmpdir)
        for chunk in chunks:
            chunk_path = tmp_root / f"{wav_path.stem}_part{chunk.index:04d}.wav"
            extract_wav_segment(
                wav_path,
                chunk_path,
                chunk.start_seconds,
                chunk.duration_seconds,
            )
            part_segments = transcriber.transcribe_path_auto(chunk_path)
            shifted = shift_segments(part_segments, chunk.start_seconds)
            collected.extend(shifted)

    merged = merge_adjacent_chunks(normalize_segment_timeline(collected))
    return merged


async def process_single_file(
    wav_path: Path,
    *,
    settings: Settings,
    input_root: Path,
    output_root: Path,
    transcriber: GeminiTranscriber,
    force: bool,
    use_state: bool,
    state: PipelineStateFile,
    state_path: Path,
    state_lock: asyncio.Lock | None,
) -> FileProcessingResult:
    """Process one WAV file end-to-end."""
    started = time.perf_counter()
    output_path = resolve_output_path(input_root, output_root, wav_path)
    key = str(wav_path.resolve())

    if (
        not force
        and output_path.exists()
        and key in state.completed_paths
        and state.completed_paths[key] == str(output_path)
    ):
        return FileProcessingResult(
            input_path=wav_path,
            output_path=output_path,
            success=True,
            duration_seconds=None,
            chunks_processed=0,
            elapsed_seconds=time.perf_counter() - started,
            detail="Skipped (resume state)",
        )

    if not force and output_path.exists():
        return FileProcessingResult(
            input_path=wav_path,
            output_path=output_path,
            success=True,
            duration_seconds=None,
            chunks_processed=0,
            elapsed_seconds=time.perf_counter() - started,
            detail="Skipped (existing SRT)",
        )

    try:
        duration_sec = probe_wav_duration_seconds(wav_path)
        chunks = plan_audio_chunks(duration_sec, settings.chunk_duration_sec)
        segments = await asyncio.to_thread(
            transcribe_wav_sync,
            wav_path,
            settings=settings,
            transcriber=transcriber,
        )
        document = build_srt_document(
            segments,
            max_chars_per_line=settings.subtitle_max_chars_per_line,
            max_lines_per_cue=settings.subtitle_max_lines_per_cue,
        )
        await write_text_async(output_path, document)

        if use_state and state_lock is not None:
            async with state_lock:
                state.completed_paths[key] = str(output_path.resolve())
                await write_json_async(state_path, state.model_dump())

        elapsed = time.perf_counter() - started
        return FileProcessingResult(
            input_path=wav_path,
            output_path=output_path,
            success=True,
            duration_seconds=duration_sec,
            chunks_processed=len(chunks),
            elapsed_seconds=elapsed,
        )
    except AudioProbeError as exc:
        return FileProcessingResult(
            input_path=wav_path,
            output_path=output_path,
            success=False,
            duration_seconds=None,
            chunks_processed=0,
            elapsed_seconds=time.perf_counter() - started,
            failure_reason=exc.reason,
            detail=str(exc),
        )
    except Exception as exc:  # noqa: BLE001
        reason = classify_gemini_failure(exc)
        return FileProcessingResult(
            input_path=wav_path,
            output_path=output_path,
            success=False,
            duration_seconds=None,
            chunks_processed=0,
            elapsed_seconds=time.perf_counter() - started,
            failure_reason=reason,
            detail=repr(exc),
        )


async def run_pipeline(args: argparse.Namespace) -> int:
    """Execute the asynchronous orchestration loop."""
    load_dotenv(PROJECT_ROOT / ".env")
    apply_cli_overrides(args)
    get_settings.cache_clear()

    settings = get_settings()
    logs_dir = settings.logs_dir
    setup_logging(settings.log_level, logs_dir)
    logger = logging.getLogger("gemini_srt")

    input_root = settings.input_dir
    output_root = settings.output_dir
    output_root.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)

    state_path = output_root / STATE_FILENAME
    state = await load_pipeline_state(state_path) if not args.no_state else PipelineStateFile()

    wav_files = discover_wav_files(input_root, recursive=args.recursive)

    if args.dry_run:
        if not wav_files:
            logger.warning("No WAV files discovered under %s", input_root)
            return 0
        logger.info("Dry run — %s files would be processed:", len(wav_files))
        for path in wav_files:
            logger.info(" • %s", path)
        return 0

    if not wav_files:
        logger.warning("No WAV files discovered under %s", input_root)
        return 1

    custom_prompt = load_prompt(args)
    transcriber = GeminiTranscriber(settings, custom_prompt=custom_prompt)

    started_at = datetime.now(timezone.utc)
    wall_start = time.perf_counter()

    semaphore = asyncio.Semaphore(settings.max_workers)
    state_lock = asyncio.Lock() if not args.no_state else None

    async def guarded(path: Path) -> FileProcessingResult:
        async with semaphore:
            return await process_single_file(
                path,
                settings=settings,
                input_root=input_root,
                output_root=output_root,
                transcriber=transcriber,
                force=args.force,
                use_state=not args.no_state,
                state=state,
                state_path=state_path,
                state_lock=state_lock,
            )

    tasks = [asyncio.create_task(guarded(path)) for path in wav_files]
    results: list[FileProcessingResult] = []
    for coro in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Transcribing"):
        results.append(await coro)

    finished_at = datetime.now(timezone.utc)
    succeeded = sum(
        1 for item in results if item.success and not (item.detail or "").startswith("Skipped")
    )
    skipped = sum(
        1 for item in results if item.success and (item.detail or "").startswith("Skipped")
    )
    failed = sum(1 for item in results if not item.success)
    report = BatchProcessingReport(
        started_at=started_at,
        finished_at=finished_at,
        total_files=len(results),
        succeeded=succeeded,
        skipped=skipped,
        failed=failed,
        total_wall_seconds=time.perf_counter() - wall_start,
        results=sorted(results, key=lambda item: str(item.input_path)),
    )

    summary_path = logs_dir / "last_run_summary.json"
    write_json_sync(summary_path, report.to_summary_dict())

    logger.info(
        "Batch complete — ok:%s skipped:%s failed:%s wall:%.2fs",
        report.succeeded,
        report.skipped,
        report.failed,
        report.total_wall_seconds,
    )

    for item in report.results:
        if not item.success:
            logger.error(
                "FAILED %s :: %s :: %s",
                item.input_path,
                item.failure_reason,
                item.detail,
            )

    return 0 if report.failed == 0 else 2


def main(argv: list[str] | None = None) -> int:
    """Shell entrypoint."""
    args = parse_args(argv)
    try:
        return asyncio.run(run_pipeline(args))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
