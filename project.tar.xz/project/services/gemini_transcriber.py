"""Gemini multimodal client for timestamped transcription."""

from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import Any

from google import genai
from google.genai import errors as genai_errors
from google.genai import types
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)

from config import Settings
from models.schemas import FailureReason, TranscriptionSegment
from utils.timestamp_utils import normalize_overlap_segments

logger = logging.getLogger(__name__)


DEFAULT_TRANSCRIPTION_PROMPT = """\
Transcribe the attached spoken audio with maximum verbatim fidelity.

Requirements:
- Preserve punctuation, capitalization, and numbering exactly as spoken when sensible.
- Preserve multilingual content exactly (do not translate).
- Emit tightly timed subtitle-sized segments (avoid extremely long lines).
- Each segment must contain human-readable subtitle text only.

Return ONLY valid JSON (no markdown fences, no commentary) with this shape:
{
  "segments": [
    {
      "start_seconds": 0.0,
      "end_seconds": 1.8,
      "text": "Example subtitle text."
    }
  ]
}

Timing rules:
- All timestamps are measured in seconds from the beginning of THIS audio clip.
- Segments must be ordered chronologically without overlap.
- Each segment should typically cover one short phrase or clause suitable for subtitles.
"""


def _strip_json_fence(raw: str) -> str:
    """Remove optional markdown code fences."""
    text = raw.strip()
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", text, flags=re.DOTALL | re.IGNORECASE)
    if fence:
        return fence.group(1).strip()
    return text


def _coerce_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _pick_float(item: dict[str, Any], keys: tuple[str, ...]) -> float | None:
    """Return the first successfully coerced float, allowing legitimate zeros."""
    for key in keys:
        if key not in item:
            continue
        coerced = _coerce_float(item.get(key))
        if coerced is not None:
            return coerced
    return None


def parse_transcription_payload(payload: str) -> list[TranscriptionSegment]:
    """Parse model output into normalized segments."""
    cleaned = _strip_json_fence(payload)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON payload: {exc}") from exc

    items: list[dict[str, Any]]
    if isinstance(data, dict) and "segments" in data:
        raw_segments = data["segments"]
        if not isinstance(raw_segments, list):
            raise ValueError("`segments` must be a list")
        items = raw_segments  # type: ignore[assignment]
    elif isinstance(data, list):
        items = data  # type: ignore[assignment]
    else:
        raise ValueError("Expected object with `segments` array or top-level array")

    segments: list[TranscriptionSegment] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        start = _pick_float(
            item,
            ("start_seconds", "start", "start_sec", "begin", "from"),
        )
        end = _pick_float(
            item,
            ("end_seconds", "end", "end_sec", "finish", "to"),
        )
        text_raw = item.get("text") or item.get("content") or item.get("subtitle")
        if start is None or end is None or text_raw is None:
            logger.debug("Skipping malformed segment at index %s: %s", idx, item)
            continue
        try:
            segments.append(
                TranscriptionSegment(
                    start_seconds=start,
                    end_seconds=end,
                    text=str(text_raw),
                )
            )
        except ValueError as exc:
            logger.warning("Discarding invalid segment %s: %s", idx, exc)

    if not segments:
        raise ValueError("No usable segments parsed from model response")
    segments.sort(key=lambda seg: (seg.start_seconds, seg.end_seconds))
    return segments


def shift_segments(
    segments: list[TranscriptionSegment],
    offset_seconds: float,
) -> list[TranscriptionSegment]:
    """Apply a constant time offset for chunked transcription merging."""
    shifted: list[TranscriptionSegment] = []
    for seg in segments:
        shifted.append(
            TranscriptionSegment(
                start_seconds=seg.start_seconds + offset_seconds,
                end_seconds=seg.end_seconds + offset_seconds,
                text=seg.text,
            )
        )
    return shifted


def normalize_segment_timeline(segments: list[TranscriptionSegment]) -> list[TranscriptionSegment]:
    """Sort and fix minor overlaps while preserving text ordering."""
    tuples = [(seg.start_seconds, seg.end_seconds, seg.text) for seg in segments]
    fixed = normalize_overlap_segments(tuples)
    return [
        TranscriptionSegment(start_seconds=start, end_seconds=end, text=text)
        for start, end, text in fixed
    ]


def merge_adjacent_chunks(segments: list[TranscriptionSegment]) -> list[TranscriptionSegment]:
    """Merge chronologically adjacent segments if boundaries touch."""
    if not segments:
        return []
    ordered = sorted(segments, key=lambda seg: (seg.start_seconds, seg.end_seconds))
    merged: list[TranscriptionSegment] = []
    eps = 5e-2
    for seg in ordered:
        if not merged:
            merged.append(seg)
            continue
        prev = merged[-1]
        if abs(seg.start_seconds - prev.end_seconds) <= eps and prev.text.strip() == seg.text.strip():
            merged[-1] = TranscriptionSegment(
                start_seconds=prev.start_seconds,
                end_seconds=max(prev.end_seconds, seg.end_seconds),
                text=prev.text,
            )
            continue
        merged.append(seg)
    return merged


def _is_retriable_exception(exc: BaseException) -> bool:
    if isinstance(exc, genai_errors.APIError):
        code = getattr(exc, "status", None) or getattr(exc, "code", None)
        message = str(exc).lower()
        if code in {408, 429, 500, 502, 503, 504}:
            return True
        if "resource exhausted" in message or "rate" in message or "timeout" in message:
            return True
    message = str(exc).lower()
    if "timeout" in message or "temporarily" in message:
        return True
    return False


class GeminiTranscriber:
    """Blocking Gemini client wrapper with retries and file lifecycle handling."""

    def __init__(self, settings: Settings, *, custom_prompt: str | None = None) -> None:
        self._settings = settings
        self._user_prompt = custom_prompt or DEFAULT_TRANSCRIPTION_PROMPT
        timeout_ms = int(settings.gemini_timeout_sec * 1000)
        self._client = genai.Client(
            api_key=settings.gemini_api_key,
            http_options=types.HttpOptions(timeout=timeout_ms),
        )
        self._generate_with_retry = retry(
            reraise=True,
            stop=stop_after_attempt(settings.max_retries),
            wait=wait_exponential_jitter(initial=1, max=60),
            retry=retry_if_exception(_is_retriable_exception),
        )(self._invoke_model)

    def _invoke_model(self, contents: list[Any]) -> str:
        response = self._client.models.generate_content(
            model=self._settings.model_name,
            contents=contents,
            config=types.GenerateContentConfig(
                temperature=0.1,
                top_p=0.95,
                system_instruction=(
                    "You are an expert broadcast subtitle specialist. "
                    "Follow formatting instructions exactly."
                ),
            ),
        )
        text = self._extract_response_text(response)
        if not text:
            raise RuntimeError("Gemini returned an empty transcription response")
        return text

    def _extract_response_text(self, response: Any) -> str | None:
        """Collect textual content from SDK response objects."""
        direct = getattr(response, "text", None)
        if isinstance(direct, str) and direct.strip():
            return direct
        candidates = getattr(response, "candidates", None) or []
        parts_buffer: list[str] = []
        for candidate in candidates:
            content = getattr(candidate, "content", None)
            parts = getattr(content, "parts", None) if content is not None else None
            if not parts:
                continue
            for part in parts:
                fragment = getattr(part, "text", None)
                if fragment:
                    parts_buffer.append(fragment)
        if parts_buffer:
            return "\n".join(parts_buffer)
        return None

    def transcribe_audio_bytes(
        self,
        audio_bytes: bytes,
        *,
        mime_type: str = "audio/wav",
    ) -> list[TranscriptionSegment]:
        """Transcribe short audio provided entirely in memory."""
        part = types.Part.from_bytes(data=audio_bytes, mime_type=mime_type)
        contents: list[Any] = [part, self._user_prompt]
        raw = self._generate_with_retry(contents)
        return parse_transcription_payload(raw)

    def _wait_for_file_ready(self, uploaded: Any) -> Any:
        """Poll Gemini File API until processing completes."""
        terminal_fail = {"FAILED", "ERROR", "STATE_FAILED"}
        for attempt in range(180):
            state = getattr(uploaded, "state", None)
            name = getattr(state, "name", None) if state is not None else None
            label = (name or str(state or "")).upper()
            if label in {"ACTIVE", "STATE_ACTIVE"}:
                return uploaded
            if any(fail in label for fail in terminal_fail):
                raise RuntimeError(f"Uploaded file entered failure state: {state}")
            time.sleep(2.0 if "PROCESS" in label or "PENDING" in label else 1.0)
            uploaded = self._client.files.get(name=uploaded.name)
            if attempt % 30 == 29:
                logger.info("Still waiting on Gemini file processing: %s", label)
        raise TimeoutError("Timed out waiting for Gemini file processing to finish")

    def transcribe_audio_file(self, path: Path) -> list[TranscriptionSegment]:
        """Upload a local audio file and transcribe it."""
        uploaded = self._client.files.upload(file=str(path))
        uploaded = self._wait_for_file_ready(uploaded)
        try:
            contents: list[Any] = [uploaded, self._user_prompt]
            raw = self._generate_with_retry(contents)
            return parse_transcription_payload(raw)
        finally:
            try:
                self._client.files.delete(name=uploaded.name)
            except genai_errors.APIError as exc:
                logger.warning("Failed to delete remote file %s: %s", uploaded.name, exc)

    def transcribe_path_auto(self, path: Path) -> list[TranscriptionSegment]:
        """Choose inline bytes vs File API based on size thresholds."""
        size = path.stat().st_size
        if size <= self._settings.inline_audio_max_bytes:
            data = path.read_bytes()
            return self.transcribe_audio_bytes(data, mime_type="audio/wav")
        return self.transcribe_audio_file(path)


def classify_gemini_failure(exc: BaseException) -> FailureReason:
    """Map exceptions to standardized failure categories."""
    message = str(exc).lower()
    if isinstance(exc, TimeoutError):
        return FailureReason.TIMEOUT
    if isinstance(exc, genai_errors.APIError):
        code = getattr(exc, "status", None)
        if code == 429:
            return FailureReason.RATE_LIMIT
        if code in {408, 504}:
            return FailureReason.TIMEOUT
        return FailureReason.API_ERROR
    if "timeout" in message:
        return FailureReason.TIMEOUT
    if "rate" in message or "quota" in message:
        return FailureReason.RATE_LIMIT
    if isinstance(exc, ValueError):
        return FailureReason.PARSE_ERROR
    return FailureReason.UNKNOWN
