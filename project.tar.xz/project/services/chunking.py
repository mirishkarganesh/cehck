"""Temporal chunk planning for long-running audio."""

from __future__ import annotations

from models.schemas import AudioChunkPlan


def plan_audio_chunks(total_duration_sec: float, chunk_duration_sec: float) -> list[AudioChunkPlan]:
    """
    Partition [0, total_duration) into contiguous chunks.

    The final chunk may be shorter than ``chunk_duration_sec`` but always positive.
    """
    if total_duration_sec <= 0:
        raise ValueError("total_duration_sec must be positive")
    if chunk_duration_sec <= 0:
        raise ValueError("chunk_duration_sec must be positive")

    chunks: list[AudioChunkPlan] = []
    start = 0.0
    index = 0
    while start < total_duration_sec - 1e-6:
        remaining = total_duration_sec - start
        duration = min(chunk_duration_sec, remaining)
        if duration <= 0:
            break
        chunks.append(
            AudioChunkPlan(
                index=index,
                start_seconds=start,
                duration_seconds=duration,
            )
        )
        start += duration
        index += 1
    return chunks
