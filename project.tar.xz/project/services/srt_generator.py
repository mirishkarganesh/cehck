"""Convert normalized transcription segments into standards-compliant SRT."""

from __future__ import annotations

import re
from typing import Iterable

from models.schemas import TranscriptionSegment
from utils.timestamp_utils import seconds_to_srt_timestamp


def _greedy_wrap_words(text: str, max_chars_per_line: int) -> list[str]:
    """Wrap a single subtitle paragraph into multiple lines."""
    words = text.split()
    if not words:
        return []
    lines: list[str] = []
    current = words[0]
    for word in words[1:]:
        candidate = f"{current} {word}"
        if len(candidate) <= max_chars_per_line:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def _group_lines_into_blocks(
    lines: list[str],
    max_lines_per_cue: int,
) -> list[str]:
    """Pack wrapped lines into subtitle cues separated by blank lines in SRT."""
    blocks: list[str] = []
    buf: list[str] = []
    for line in lines:
        buf.append(line)
        if len(buf) >= max_lines_per_cue:
            blocks.append("\n".join(buf))
            buf = []
    if buf:
        blocks.append("\n".join(buf))
    return blocks


def _split_long_token(token: str, max_chars_per_line: int) -> list[str]:
    """Hard-split a token that exceeds the maximum line length."""
    return [token[i : i + max_chars_per_line] for i in range(0, len(token), max_chars_per_line)]


def split_segment_into_timed_cues(
    segment: TranscriptionSegment,
    *,
    max_chars_per_line: int,
    max_lines_per_cue: int,
) -> list[tuple[float, float, str]]:
    """
    Split a logical segment into one or more timed cues.

    Timing is distributed proportionally by character weight to preserve pacing.
    """
    start = segment.start_seconds
    end = segment.end_seconds
    duration = max(end - start, 1e-3)
    raw_text = " ".join(segment.text.split())
    if not raw_text:
        return []

    lines = _greedy_wrap_words(raw_text, max_chars_per_line)
    adjusted_lines: list[str] = []
    for line in lines:
        if len(line) <= max_chars_per_line:
            adjusted_lines.append(line)
        else:
            adjusted_lines.extend(_split_long_token(line, max_chars_per_line))

    blocks = _group_lines_into_blocks(adjusted_lines, max_lines_per_cue)
    weights = [max(1, len(re.sub(r"\s+", "", block))) for block in blocks]
    total_w = float(sum(weights))

    cues: list[tuple[float, float, str]] = []
    cursor = start
    for idx, (block, weight) in enumerate(zip(blocks, weights, strict=True)):
        chunk_duration = duration * (weight / total_w)
        cue_end = cursor + chunk_duration
        if idx == len(blocks) - 1:
            cue_end = end
        cues.append((cursor, cue_end, block))
        cursor = cue_end

    # Prevent rounding drift
    if cues:
        last_start, _last_end, last_text = cues[-1]
        cues[-1] = (last_start, end, last_text)

    return cues


def build_srt_document(
    segments: Iterable[TranscriptionSegment],
    *,
    max_chars_per_line: int,
    max_lines_per_cue: int,
) -> str:
    """Render ordered segments into an SRT document string (UTF-8)."""
    cues: list[tuple[float, float, str]] = []
    for segment in segments:
        cues.extend(
            split_segment_into_timed_cues(
                segment,
                max_chars_per_line=max_chars_per_line,
                max_lines_per_cue=max_lines_per_cue,
            )
        )

    cues.sort(key=lambda item: (item[0], item[1]))
    blocks: list[str] = []
    for idx, (start, end, text) in enumerate(cues, start=1):
        start_ts = seconds_to_srt_timestamp(start)
        end_ts = seconds_to_srt_timestamp(end)
        blocks.append(f"{idx}\n{start_ts} --> {end_ts}\n{text}\n")
    return "\n".join(blocks).rstrip() + "\n"
