"""FFmpeg-based audio inspection and chunk extraction."""

from __future__ import annotations

import logging
import subprocess
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from models.schemas import FailureReason
from utils.validators import AudioProbeError

logger = logging.getLogger(__name__)


def extract_wav_segment(
    source: Path,
    destination: Path,
    start_seconds: float,
    duration_seconds: float,
    *,
    ffmpeg_bin: str = "ffmpeg",
) -> None:
    """
    Extract a contiguous slice of audio into a standalone WAV file.

    Re-encodes to PCM 16-bit mono at 16 kHz for consistent Gemini ingestion.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        ffmpeg_bin,
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-ss",
        f"{start_seconds:.6f}",
        "-i",
        str(source),
        "-t",
        f"{duration_seconds:.6f}",
        "-ac",
        "1",
        "-ar",
        "16000",
        "-c:a",
        "pcm_s16le",
        str(destination),
    ]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
            timeout=max(300.0, duration_seconds * 4),
        )
    except subprocess.TimeoutExpired as exc:
        raise AudioProbeError(
            f"ffmpeg timed out extracting chunk from {source}",
            FailureReason.FFMPEG_ERROR,
        ) from exc
    except FileNotFoundError as exc:
        raise AudioProbeError(
            "ffmpeg executable not found; install FFmpeg.",
            FailureReason.FFMPEG_ERROR,
        ) from exc

    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        raise AudioProbeError(
            f"ffmpeg failed: {err}",
            FailureReason.FFMPEG_ERROR,
        )


@contextmanager
def temporary_wav_file(prefix: str = "chunk_") -> Iterator[Path]:
    """Yield a temporary WAV path and delete the file afterwards."""
    with tempfile.NamedTemporaryFile(
        suffix=".wav",
        prefix=prefix,
        delete=False,
    ) as handle:
        path = Path(handle.name)
    try:
        yield path
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            logger.warning("Could not delete temporary file %s", path)
