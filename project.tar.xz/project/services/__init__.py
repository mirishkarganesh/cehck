"""Application services (Gemini, FFmpeg chunking, SRT rendering)."""
