# Gemini Audio → SRT Pipeline

Production-oriented batch utility that transcribes `.wav` files with **Google Gemini** multimodal audio, emits **timestamped JSON**, and renders **SubRip (`.srt`)** subtitles with sensible line wrapping, Unicode preservation, chunking for long media, retries, structured logging, and async orchestration.

## Features

- Recursive WAV discovery, parallel **file-level** workers (asyncio + semaphores), FFmpeg slicing for media longer than `CHUNK_DURATION_SEC`.
- **Resume**: skips existing outputs and persists `.gemini_srt_state.json` under the output directory (disable via `--no-state`).
- **Fault isolation**: one corrupt file or API failure does not stop the batch.
- **Rich** console logs + rotating **file** logs under `logs/` + JSON summary `logs/last_run_summary.json`.
- **Tenacity** exponential backoff for rate limits and transient 5xx errors.

## Prerequisites

- **Python 3.11+**
- **FFmpeg** & **ffprobe** on `PATH` (`ffmpeg`, `ffprobe`).
- **Gemini API key** from [Google AI Studio](https://aistudio.google.com/apikey).

### FFmpeg (Ubuntu / Debian)

```bash
sudo apt-get update && sudo apt-get install -y ffmpeg
ffmpeg -version
```

### Python environment

Using the provided Conda environment path:

```bash
conda activate /hdd0/envs/gem
cd /hdd0/codes/project
pip install -r requirements.txt
cp .env.example .env
# Edit .env and set GEMINI_API_KEY and paths as needed
```

## Configuration

Environment variables are loaded from `.env` (see `.env.example`):

| Variable | Purpose |
|----------|---------|
| `GEMINI_API_KEY` | Required developer API key |
| `MODEL_NAME` | Gemini model id (must support audio input) |
| `MAX_WORKERS` | Concurrent WAV files processed |
| `INPUT_DIR` | Root folder scanned for `.wav` |
| `OUTPUT_DIR` | Root folder for `.srt` output (mirrors subfolders) |
| `LOGS_DIR` | Log output directory |
| `LOG_LEVEL` | `DEBUG` … `ERROR` |
| `CHUNK_DURATION_SEC` | FFmpeg slice length for long audio |
| `GEMINI_TIMEOUT_SEC` | HTTP timeout per request |
| `MAX_RETRIES` | Tenacity attempts for retriable failures |
| `INLINE_AUDIO_MAX_BYTES` | Threshold for inline bytes vs File API upload |
| `SUBTITLE_MAX_CHARS_PER_LINE` | Target caption width |
| `SUBTITLE_MAX_LINES_PER_CUE` | Lines per subtitle block |

CLI flags override several of these for one-off runs (see below).

## Usage

Place WAV files under `INPUT_DIR` (or pass `--input-dir`). Outputs preserve relative paths:

```
input_audio/podcasts/ep1.wav  →  outputs/podcasts/ep1.srt
```

### Basic run

```bash
cd /hdd0/codes/project
conda activate /hdd0/envs/gem
python main.py
```

### Recursive discovery

```bash
python main.py --recursive
```

### Tune parallelism & chunk size

```bash
python main.py --workers 8 --chunk-duration 180
```

### Custom model & prompt

```bash
python main.py --model gemini-2.5-flash --prompt-file ./prompts/custom_instruction.txt
```

### Force regeneration

```bash
python main.py --force
```

### Dry run (no API calls)

```bash
python main.py --recursive --dry-run
```

### Exit codes

- `0` — completed with zero failures  
- `1` — no WAV files found  
- `2` — one or more files failed (others may still succeed)  
- `130` — interrupted (Ctrl+C)

## Project layout

```
project/
├── main.py
├── config.py
├── requirements.txt
├── .env.example
├── README.md
├── services/
│   ├── gemini_transcriber.py
│   ├── srt_generator.py
│   ├── audio_processor.py
│   └── chunking.py
├── utils/
│   ├── logger.py
│   ├── file_utils.py
│   ├── timestamp_utils.py
│   └── validators.py
├── models/
│   └── schemas.py
├── outputs/
├── logs/
└── input_audio/
```

## Operational notes

### Chunking & merging

Long inputs are split with FFmpeg into PCM WAV chunks (mono 16 kHz) for predictable token/API behavior. Each chunk is transcribed independently; timestamps are **offset by chunk start** and merged with light overlap correction.

### Rate limits

Increase backoff patience via `MAX_RETRIES` / `GEMINI_TIMEOUT_SEC`, or reduce `MAX_WORKERS` to lower concurrent quota consumption.

### Performance tuning

| Goal | Suggestion |
|------|------------|
| Many short files | Raise `MAX_WORKERS` until quota saturates |
| Very long podcasts | Lower `CHUNK_DURATION_SEC` if models truncate; raise if overhead dominates |
| Disk / bandwidth | Lower `INLINE_AUDIO_MAX_BYTES` to favor streaming uploads (trade-offs vary) |
| Cost | Use a smaller/faster model (`MODEL_NAME`) when quality permits |

### Scaling out

- **Horizontal**: shard input folders across machines or containers; each instance runs this CLI with disjoint `--input-dir`.
- **Vertical**: raise `MAX_WORKERS` subject to Gemini quota and egress bandwidth.
- **Kubernetes**: wrap the container command as `python main.py --input-dir /data/in --output-dir /data/out`; mount PVCs for audio + outputs; store `GEMINI_API_KEY` in a Secret.

## Troubleshooting

| Symptom | Mitigation |
|---------|------------|
| `ffprobe executable not found` | Install FFmpeg; verify `which ffprobe` |
| `429` / rate limit errors | Lower `--workers`, increase `MAX_RETRIES`, wait, or request higher quota |
| Empty / malformed JSON from model | Re-run with `--force`; tighten prompt via `--prompt-file`; try another `MODEL_NAME` |
| File API stuck processing | Usually resolves; otherwise raise `GEMINI_TIMEOUT_SEC` or split audio smaller |
| Wrong relative output paths | Ensure WAVs live under `INPUT_DIR` when using nested layouts + `--recursive` |

## License

Use and modify within your organization’s compliance policies. Google Gemini usage is subject to **Google AI / Gemini API terms**.
