"""Application configuration loaded from environment and CLI overrides."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration sourced from `.env` and environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    gemini_api_key: str = Field(
        ...,
        alias="GEMINI_API_KEY",
        description="Google Gemini API key (AI Studio / Gemini Developer API).",
    )
    model_name: str = Field(
        default="gemini-2.5-flash",
        alias="MODEL_NAME",
        description="Gemini model id for multimodal transcription.",
    )
    max_workers: int = Field(default=4, ge=1, le=128, alias="MAX_WORKERS")
    input_dir: Path = Field(default=Path("input_audio"), alias="INPUT_DIR")
    output_dir: Path = Field(default=Path("outputs"), alias="OUTPUT_DIR")
    logs_dir: Path = Field(default=Path("logs"), alias="LOGS_DIR")
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        alias="LOG_LEVEL",
    )
    chunk_duration_sec: float = Field(
        default=240.0,
        gt=10.0,
        le=3600.0,
        alias="CHUNK_DURATION_SEC",
        description="Maximum duration per Gemini request; larger audio is split.",
    )
    inline_audio_max_bytes: int = Field(
        default=18 * 1024 * 1024,
        ge=1024 * 1024,
        alias="INLINE_AUDIO_MAX_BYTES",
        description="Above this size, audio is uploaded via the File API.",
    )
    gemini_timeout_sec: float = Field(
        default=600.0,
        ge=30.0,
        alias="GEMINI_TIMEOUT_SEC",
    )
    max_retries: int = Field(default=6, ge=1, le=20, alias="MAX_RETRIES")
    subtitle_max_chars_per_line: int = Field(
        default=42,
        ge=20,
        le=80,
        alias="SUBTITLE_MAX_CHARS_PER_LINE",
    )
    subtitle_max_lines_per_cue: int = Field(
        default=2,
        ge=1,
        le=3,
        alias="SUBTITLE_MAX_LINES_PER_CUE",
    )

    @field_validator("input_dir", "output_dir", "logs_dir", mode="before")
    @classmethod
    def coerce_path(cls, value: str | Path) -> Path:
        return Path(value).expanduser().resolve() if value else Path()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings (single process lifetime)."""
    return Settings()
